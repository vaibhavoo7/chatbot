from flask import Flask, render_template, request
from chatterbot import ChatBot
from chatterbot.trainers import ChatterBotCorpusTrainer

chatbot = ChatBot('Chatty')
trainer = ChatterBotCorpusTrainer(chatbot)
#trainer.train("chatterbot.corpus.english")
#trainer.train("chatterbot.corpus.english.greetings")
#trainer.train("chatterbot.corpus.english.conversations")

app = Flask(__name__)
@app.route("/home")
def index():
    return render_template('index.html')
@app.route('/process',methods=['POST'])
def process():
    message=request.form['message']
    reply=chatbot.get_response(message)
    reply=str(reply)
    print('Chatty:'+reply)
    return render_template('index.html',message=message,reply=reply)

if __name__=='__main__':
    app.run()
